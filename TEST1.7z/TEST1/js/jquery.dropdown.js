$(document).ready(function(){
    $(".dropdown").click(function(){
        $(".stations").slideToggle();
    });
})
